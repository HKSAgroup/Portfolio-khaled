import React, { createContext } from "react";

const CreateContext = createContext();

export default CreateContext;
