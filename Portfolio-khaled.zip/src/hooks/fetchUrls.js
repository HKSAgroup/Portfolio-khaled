
// const FetchUrls = (url) => ` https://backend.lobdho.com/clickthepoint/api/v1/${url}`
const FetchUrls = (url) => ` https://backend.lobdho.com/clickthepoint/api/v1/${url}`

export default FetchUrls