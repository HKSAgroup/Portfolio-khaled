"use strict";
exports.id = 341;
exports.ids = [341];
exports.modules = {

/***/ 9341:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Services_ServicesItem)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./src/assets/Service/Artboard – 1 1.png
/* harmony default export */ const Artboard_1_1 = ({"src":"/_next/static/media/Artboard – 1 1.43d52c06.png","height":242,"width":373,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAAiElEQVR42gF9AIL/AIur5gBT1Thz2h9p2RZr19jV2ezk3evq7wCVsuhPeNqSp+RYgt5Qctbc1tff1N7Z5fcA7vb89/X48PL57PD57/L32N7h9PP18fr8APf//+rp7unp7Pv7+vj6+fD19P/+/vT8/wD0/P7p6vDu8PX////4+PnDwsO8u7vDztN1UmOGehzS0AAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./src/Components/Services/ServicesItem.js




const ServicesItem = ()=>{
    const router = (0,router_.useRouter)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                onClick: ()=>router.push("/service/[id]"),
                src: "https://i.ibb.co/Pjf1Nbh/Artboard-1-1-43d52c06.png",
                alt: "image",
                width: 500,
                height: 500,
                h: true,
                className: "w-full cursor-pointer"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mt-4 pr-3",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex justify-between items-center border-l-4 pl-4 border-primary ",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                onClick: ()=>router.push("/service/[id]"),
                                className: "font-medium cursor-pointer hover:text-primary duration-200",
                                children: "Agency Website"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-sm text-neutral",
                                children: "30$"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: "pl-4 mt-2 text-sm text-neutral leading-6",
                        children: [
                            "Event madness we take are gathering  innovatEvent madness  on gathering innovators. ",
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            " It’s the freas bake ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "text-primary",
                                children: "more"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Services_ServicesItem = (ServicesItem);


/***/ })

};
;